import './App.css'
import Data from './conditional/Data'
import Fetch_api from './Fetch_api'



function App() {

  return (
    <>
      {/* <Fetch_api /> */}
      <Data />
    </>
  )
}

export default App
