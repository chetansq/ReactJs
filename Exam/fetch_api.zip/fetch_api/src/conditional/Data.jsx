import React from 'react'
import Online_ofline from './Online_ofline'

const Data = () => {
    return (
        <div>
            <Online_ofline data='online' />
        </div>
    )
}

export default Data
